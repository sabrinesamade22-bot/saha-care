# Saha-Care (démonstration)
1. Installer Node.js 18+, ouvrir ce dossier dans VS Code (Fichier > Ouvrir le dossier).
2. Terminal > Nouveau terminal : `npm install` puis `npm run dev`.
3. Ouvrir l'adresse affichée (http://localhost:5173).

Comptes démo (mot de passe `demo1234`) : patient@demo.ma, cabinet@demo.ma, medecin@demo.ma, labo@demo.ma, radio@demo.ma.

## Commandes
- `npm run dev` : serveur de développement
- `npm run build` : build de production
- `npm test` : tests automatiques (recherche, migration des données, formulaires, profil médical)

## Données
- Tout est stocké dans le LocalStorage du navigateur (mots de passe en clair : **démonstration uniquement**).
- `src/data/cities.js` : liste unique des villes marocaines, utilisée par toutes les pages.
- `src/data/catalog.js` : spécialités, catégories d'analyses, types d'examens de radiologie.
- `src/data/demo.js` : **fiches de démonstration fictives** (`demo: true`, numéros 05 00 00 00 xx). Elles sont signalées
  comme telles dans l'interface et jamais présentées comme « vérifiées ». Pour utiliser de vraies données, remplacer
  `DEMO.providers` (ou charger une API) en gardant la même structure, puis incrémenter `DATA_VERSION` dans `src/services/store.js`.
- `DATA_VERSION` : quand elle augmente, les fiches de démonstration sont régénérées au prochain chargement ;
  les comptes et fiches créés par les utilisateurs sont conservés.
- `src/services/search.js` : moteur de recherche (filtres ville / spécialité / analyse / examen / nom), sans dépendance à React.

Une vraie application médicale exige backend sécurisé, authentification réelle, contrôle d'accès, stockage chiffré et conformité à la loi marocaine 09-08.
