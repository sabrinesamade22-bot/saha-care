export const Field = ({ label, children }) => <label className="f"><span>{label}</span>{children}</label>;
export const Badge = ({ s }) => <span className={'badge b-' + s.replace(/\s/g, '').replace('é', 'e').toLowerCase()}>{s}</span>;
export const Empty = ({ icon, text }) => <div className="empty">{icon}<p>{text}</p></div>;
export const Stat = ({ n, label }) => <div className="stat"><b>{n}</b><span>{label}</span></div>;
export const DemoNotice = () => <div className="notice">Les médecins, cabinets, laboratoires et centres affichés sont des fiches de démonstration fictives (prix et disponibilités inventés).</div>;
export const ROLE_LABEL = { patient: 'Patient', doctor: 'Médecin', cabinet: 'Cabinet médical', lab: 'Laboratoire', radio: 'Centre de radiologie' };
export const KIND_LABEL = { rdv: 'Consultation', analyse: 'Analyse', radio: 'Radiologie' };
