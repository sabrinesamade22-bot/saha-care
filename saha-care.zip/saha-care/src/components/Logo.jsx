// Logo Saha-Care : croix médicale blanche sur pastille rouge, traversée d'un tracé de pouls ; nom en gris et rouge.
export function LogoMark({ size = 32 }) {
  return <svg width={size} height={size} viewBox="0 0 40 40" role="img" aria-label="Saha-Care" className="logo-mark">
    <rect width="40" height="40" rx="11" fill="var(--red)" />
    <rect x="7" y="14" width="26" height="12" rx="3.5" fill="var(--paper)" /><rect x="14" y="7" width="12" height="26" rx="3.5" fill="var(--paper)" />
    <polyline points="8.5,20 15,20 17.5,14.5 21.5,25.5 24,20 31.5,20" fill="none" stroke="var(--red)" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" />
  </svg>;
}
export default function Logo({ size = 32, text = true }) {
  return <span className="logo-wrap"><LogoMark size={size} />{text && <span className="logo-t" style={{ fontSize: size * 0.72 }}>Saha<i>-</i><b>Care</b></span>}</span>;
}
