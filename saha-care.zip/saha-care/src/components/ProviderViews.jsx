import { useEffect, useRef } from 'react';
import { Stethoscope, Building2, FlaskConical, ScanLine, MapPin, Phone, Clock, X, Home as HomeIcon, Users } from 'lucide-react';
import { provSpecs, hasPrice, norm } from '../services/search.js';

const ICON = { doctor: Stethoscope, cabinet: Building2, lab: FlaskConical, radio: ScanLine };
export const TYPE_LABEL = { doctor: 'Médecin', cabinet: 'Cabinet médical', lab: 'Laboratoire', radio: 'Centre de radiologie' };

export function Avatar({ p, big }) {
  const I = ICON[p.type] || Building2;
  return <div className={'avatar' + (big ? ' big' : '')}>{p.photo ? <img src={p.photo} alt={p.name} /> : <I size={big ? 30 : 22} />}</div>;
}
// Ne jamais présenter une donnée de démonstration comme vérifiée.
export function Status({ p }) {
  if (p.demo) return <span className="tag tag-demo" title="Fiche fictive, créée pour tester la recherche">Donnée de démonstration</span>;
  return p.verified ? <span className="tag ok">Vérifié</span> : <span className="tag warn">En attente de vérification</span>;
}
const Line = ({ icon, children }) => <p className="line">{icon}<span>{children}</span></p>;

function Services({ p, term }) {
  if (!p.services?.length) return null;
  return <ul className="svc">{p.services.map((s) => <li key={s.name} className={term && norm(s.name) === norm(term) ? 'hit' : ''}><span>{s.name}</span>{hasPrice(s) ? <b>{s.price} MAD <small>indicatif</small></b> : <small>Tarif non communiqué</small>}</li>)}</ul>;
}

export function ResultCard({ p, term, chosen, actionLabel, onDetails, onChoose }) {
  const specs = provSpecs(p);
  return <article className={'card res' + (chosen ? ' sel' : '')}>
    <div className="res-head"><Avatar p={p} /><div><h3>{p.name}</h3><Status p={p} /></div></div>
    {specs.length > 0 && <p className="specs">{specs.join(' · ')}</p>}
    {p.type === 'doctor' && p.cabinet && <Line icon={<Building2 size={15} />}>{p.cabinet}</Line>}
    {p.type === 'cabinet' && p.doctors?.length > 0 && <Line icon={<Users size={15} />}>{p.doctors.join(', ')}</Line>}
    <Line icon={<MapPin size={15} />}>{[p.address, p.city].filter(Boolean).join(', ')}</Line>
    {p.phone && <Line icon={<Phone size={15} />}>{p.phone}</Line>}
    {p.hours && <Line icon={<Clock size={15} />}>{p.hours}</Line>}
    <Services p={p} term={term} />
    {p.type === 'lab' && p.home && <small className="home"><HomeIcon size={13} /> Prélèvement à domicile disponible</small>}
    <div className="acts"><button type="button" className="btn sm" onClick={() => onChoose(p)}>{actionLabel}</button><button type="button" className="btn sm ghost" onClick={() => onDetails(p)}>Voir les détails</button>
      {(p.type === 'lab' || p.type === 'radio') && p.phone && <a className="btn sm ghost" href={'tel:' + p.phone.replace(/\s/g, '')}><Phone size={14} /> Contacter</a>}</div>
  </article>;
}

export function Details({ p, term, actionLabel, onClose, onChoose }) {
  const closeRef = useRef(null);
  useEffect(() => { closeRef.current?.focus(); const k = (e) => e.key === 'Escape' && onClose(); window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k); }, [onClose]);
  const specs = provSpecs(p);
  return <div className="overlay" onClick={onClose}><div className="modal card" role="dialog" aria-modal="true" aria-label={'Détails : ' + p.name} onClick={(e) => e.stopPropagation()}>
    <button ref={closeRef} type="button" className="x close" aria-label="Fermer" onClick={onClose}><X size={20} /></button>
    <div className="res-head"><Avatar p={p} big /><div><small>{TYPE_LABEL[p.type]}</small><h2>{p.name}</h2><Status p={p} /></div></div>
    {specs.length > 0 && <p className="specs">{specs.join(' · ')}</p>}
    {p.type === 'doctor' && p.cabinet && <Line icon={<Building2 size={15} />}>Exerce au {p.cabinet}</Line>}
    {p.type === 'cabinet' && p.doctors?.length > 0 && <Line icon={<Users size={15} />}>Médecins : {p.doctors.join(', ')}</Line>}
    <Line icon={<MapPin size={15} />}>{[p.address, p.city].filter(Boolean).join(', ')}</Line>
    {p.phone && <Line icon={<Phone size={15} />}>{p.phone}</Line>}{p.hours && <Line icon={<Clock size={15} />}>Horaires : {p.hours}</Line>}
    {p.description && <p>{p.description}</p>}
    {p.services?.length > 0 && <><h4>{p.type === 'lab' ? 'Analyses proposées' : 'Examens proposés'}</h4><Services p={p} term={term} /></>}
    {p.type === 'lab' && <small className="home"><HomeIcon size={13} /> {p.home ? 'Prélèvement à domicile disponible' : 'Au laboratoire uniquement'}</small>}
    {p.demo && <p className="hint">Cette fiche est fictive : nom, adresse, numéro et tarifs sont inventés pour la démonstration.</p>}
    <div className="acts"><button type="button" className="btn" onClick={() => { onClose(); onChoose(p); }}>{actionLabel}</button>
      {p.phone && <a className="btn ghost" href={'tel:' + p.phone.replace(/\s/g, '')}><Phone size={16} /> Appeler</a>}</div>
  </div></div>;
}
