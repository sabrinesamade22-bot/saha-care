import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import Logo from './Logo.jsx';
export default function Navbar() {
  const { user } = useAuth();
  return <nav className="nav"><Link to="/" className="logo" aria-label="Saha-Care, accueil"><Logo size={34} /></Link>
    <div>{user ? <Link className="btn" to="/espace">Mon espace</Link> : <><Link className="btn ghost" to="/connexion">Se connecter</Link><Link className="btn" to="/inscription">Créer un compte</Link></>}</div></nav>;
}
