import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './context/AuthContext.jsx';
import Home from './pages/Home.jsx';
import { Login, Register } from './pages/Auth.jsx';
import PatientSpace from './pages/PatientSpace.jsx';
import ProSpace from './pages/ProSpace.jsx';
function Space() {
  const { user } = useAuth();
  if (!user) return <Navigate to="/connexion" />;
  return user.role === 'patient' ? <PatientSpace /> : <ProSpace />;
}
export default function App() {
  return <Routes><Route path="/" element={<Home />} /><Route path="/connexion" element={<Login />} /><Route path="/inscription" element={<Register />} /><Route path="/espace" element={<Space />} /><Route path="*" element={<Navigate to="/" />} /></Routes>;
}
