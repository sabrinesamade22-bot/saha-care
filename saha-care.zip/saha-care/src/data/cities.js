// Liste unique des villes marocaines, réutilisée par toutes les pages (recherches, inscription, fiche).
// Les 15 principales villes sont en tête, les autres suivent par ordre alphabétique.
const MAIN = ['Casablanca', 'Rabat', 'Marrakech', 'Fès', 'Tanger', 'Agadir', 'Meknès', 'Oujda', 'Tétouan', 'Kénitra', 'Safi', 'El Jadida', 'Béni Mellal', 'Nador', 'Settat'];
const OTHERS = ['Al Hoceïma', 'Azrou', 'Berkane', 'Berrechid', 'Chefchaouen', 'Dakhla', 'Errachidia', 'Essaouira', 'Guelmim', 'Ifrane', 'Khémisset', 'Khénifra', 'Khouribga', 'Laâyoune', 'Larache', 'Mohammédia', 'Ouarzazate', 'Salé', 'Sidi Kacem', 'Skhirat', 'Taza', 'Témara', 'Tiznit'];
export const CITIES = [...MAIN, ...OTHERS.sort((a, b) => a.localeCompare(b, 'fr'))];
