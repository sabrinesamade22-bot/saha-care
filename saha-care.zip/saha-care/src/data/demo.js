// ─────────────────────────────────────────────────────────────────────────────
// DONNÉES DE DÉMONSTRATION — TOUT EST FICTIF.
// Noms, adresses, numéros (05 00 00 00 xx), prix et horaires sont inventés pour tester les recherches.
// Chaque fiche porte `demo: true` : l'interface l'affiche et ne la présente jamais comme « vérifiée ».
//
// POUR PASSER À DE VRAIES DONNÉES : remplacer le contenu de `providers` (ou charger la liste depuis une
// API) en conservant la structure ci-dessous, puis incrémenter DATA_VERSION dans store.js.
//   Provider = { id, type: 'doctor'|'cabinet'|'lab'|'radio', name, city, specialties: [], doctors: [],
//                cabinet, address, phone, hours, services: [{name, price}], slots: [], home, verified, demo, photo }
// ─────────────────────────────────────────────────────────────────────────────
const SLOTS = ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00'];
const HOURS = ['Lun-Ven 9h-17h', 'Lun-Sam 10h-18h', 'Lun-Sam 9h-19h', 'Lun-Ven 9h-16h'];
let n = 0;
const phone = () => '05 00 00 00 ' + String(++n).padStart(2, '0');
const base = (id, type, name, city, address, hours, extra = {}) => ({ id, type, name, city, specialties: [], doctors: [], cabinet: '', address, phone: phone(), hours, services: [], slots: SLOTS, home: false, photo: '', verified: false, demo: true, ...extra });

// Médecins : [id, prénom, nom, ville, spécialité, quartier]
const DOCTORS = [
  ['p1', 'Amina', 'Fictive', 'Casablanca', 'Cardiologie', 'Maarif'], ['d10', 'Hicham', 'Démo', 'Casablanca', 'Cardiologie', 'Gauthier'],
  ['d11', 'Nadia', 'Échantillon', 'Casablanca', 'Cardiologie', 'Anfa'], ['d12', 'Rachid', 'Test', 'Casablanca', 'Pédiatrie', 'Bourgogne'], ['d13', 'Leila', 'Simulée', 'Casablanca', 'Dermatologie', 'Oasis'],
  ['p2', 'Karim', 'Exemple', 'Rabat', 'Dermatologie', 'Agdal'], ['d14', 'Sofia', 'Illustrative', 'Rabat', 'Cardiologie', 'Hassan'], ['d15', 'Omar', 'Prototype', 'Rabat', 'Pédiatrie', 'Souissi'], ['d16', 'Imane', 'Fictive', 'Rabat', 'Gynécologie-obstétrique', 'Océan'],
  ['d17', 'Yassine', 'Démo', 'Marrakech', 'Cardiologie', 'Guéliz'], ['d18', 'Hanane', 'Essai', 'Marrakech', 'Dermatologie', 'Hivernage'],
  ['d19', 'Mehdi', 'Exemple', 'Fès', 'Neurologie', 'Ville Nouvelle'], ['d20', 'Zineb', 'Modèle', 'Fès', 'Cardiologie', 'Atlas'],
  ['p4', 'Salma', 'Modèle', 'Tanger', 'Endocrinologie', 'Centre'], ['d21', 'Anas', 'Test', 'Tanger', 'Cardiologie', 'Malabata'], ['d22', 'Kenza', 'Démo', 'Tanger', 'Pédiatrie', 'Iberia'],
  ['d23', 'Brahim', 'Fictif', 'Agadir', 'Orthopédie', 'Founty'], ['d24', 'Soukaina', 'Exemple', 'Agadir', 'Cardiologie', 'Talborjt'],
  ['d25', 'Tarik', 'Modèle', 'Meknès', 'Pneumologie', 'Hamria'], ['d26', 'Asmae', 'Test', 'Meknès', 'Médecine générale', 'Marjane'],
  ['d27', 'Reda', 'Démo', 'Oujda', 'Cardiologie', 'Centre'], ['d28', 'Fatima', 'Essai', 'Oujda', 'Gastro-entérologie', 'Al Qods'],
  ['d29', 'Ilyas', 'Exemple', 'Tétouan', 'Ophtalmologie', 'Martil Road'], ['d30', 'Houda', 'Prototype', 'Tétouan', 'Cardiologie', 'Wilaya'],
  ['d31', 'Badr', 'Simulé', 'Kénitra', 'Pédiatrie', 'Centre'], ['d32', 'Meryem', 'Démo', 'Kénitra', 'Dermatologie', 'Val Fleuri'],
  ['d33', 'Walid', 'Test', 'Safi', 'Médecine générale', 'Centre'], ['d34', 'Sara', 'Modèle', 'Safi', 'Cardiologie', 'Jawhara'],
  ['d35', 'Adil', 'Fictif', 'El Jadida', 'Cardiologie', 'Plage'], ['d36', 'Rim', 'Exemple', 'El Jadida', 'Gynécologie-obstétrique', 'Centre'],
  ['d37', 'Samir', 'Démo', 'Béni Mellal', 'Orthopédie', 'Centre'], ['d38', 'Chaimae', 'Essai', 'Béni Mellal', 'Cardiologie', 'Hay Salam'],
  ['d39', 'Jawad', 'Test', 'Nador', 'Cardiologie', 'Centre'], ['d40', 'Noura', 'Modèle', 'Nador', 'Pédiatrie', 'Ouled Mimoun'],
  ['d41', 'Hamza', 'Exemple', 'Settat', 'Endocrinologie', 'Centre'], ['d42', 'Ghita', 'Démo', 'Settat', 'Cardiologie', 'Hay Al Fath'],
].map(([id, first, last, city, spec, quartier], i) => base(id, 'doctor', `Dr ${first} ${last}`, city, `${3 + i} rue Exemple, ${quartier}`, HOURS[i % 4], { specialties: [spec], cabinet: `Cabinet médical ${quartier} (fictif)` }));

// Cabinets médicaux : [id, nom, ville, adresse, spécialités, médecins]
const CABINETS = [
  ['p3', 'Cabinet Médical Atlas (fictif)', 'Marrakech', '8 rue Test, Guéliz', ['Médecine générale', 'Pédiatrie'], ['Dr Hind Atlas-Test', 'Dr Amine Démo']],
  ['c1', 'Cabinet Médical Anfa (fictif)', 'Casablanca', '40 boulevard Démo, Anfa', ['Cardiologie', 'Médecine générale'], ['Dr Salim Exemple', 'Dr Rania Fictive']],
  ['c2', 'Cabinet Médical Agdal (fictif)', 'Rabat', '17 avenue Test, Agdal', ['Dermatologie', 'Pédiatrie'], ['Dr Lamia Modèle']],
  ['c3', 'Cabinet Médical Atlas Fès (fictif)', 'Fès', '6 rue Essai, Ville Nouvelle', ['Cardiologie', 'Neurologie'], ['Dr Oussama Démo', 'Dr Btissam Test']],
  ['c4', 'Cabinet Médical Marshan (fictif)', 'Tanger', '22 rue Exemple, Marshan', ['Gynécologie-obstétrique', 'Médecine générale'], ['Dr Nawal Simulée']],
  ['c5', 'Cabinet Médical Souss (fictif)', 'Agadir', '11 avenue Démo, Founty', ['Cardiologie', 'Orthopédie'], ['Dr Younes Essai', 'Dr Majda Modèle']],
].map(([id, name, city, address, specialties, doctors], i) => base(id, 'cabinet', name, city, address, HOURS[(i + 1) % 4], { specialties, doctors }));

// Prix indicatifs de référence (MAD), modulés par un coefficient propre à chaque établissement.
const PRICE = { Glycémie: 40, NFS: 90, 'Bilan lipidique': 150, TSH: 180, 'Bilan hépatique': 160, Créatinine: 50, CRP: 70, Ferritine: 120, 'Vitamine D': 300, ECBU: 110, Albuminurie: 60, 'Prélèvement de gorge': 130, Coproculture: 140,
  Radiographie: 200, Échographie: 350, Scanner: 900, IRM: 1400, Mammographie: 450, 'Panoramique dentaire': 150, 'Densitométrie osseuse': 300, Doppler: 500 };
const svc = (names, k) => names.map((s) => ({ name: s, price: Math.round((PRICE[s] * k) / 5) * 5 }));
const BIO = ['Glycémie', 'NFS', 'Bilan lipidique', 'TSH', 'Bilan hépatique', 'Créatinine', 'CRP', 'Ferritine', 'Vitamine D'];
const pick = (arr, from, len) => Array.from({ length: len }, (_, i) => arr[(from + i) % arr.length]);

// Laboratoires : [id, nom, ville, adresse, horaires, services, domicile, coeff]
const LABS = [
  ['p5', 'Laboratoire Horizon (fictif)', 'Casablanca', '21 rue Démo, Centre-ville', 'Lun-Sam 7h-18h', ['Glycémie', 'NFS', 'Bilan lipidique'], true, 1],
  ['p6', 'Laboratoire Al Amal (fictif)', 'Casablanca', '7 avenue Exemple, Gauthier', 'Lun-Ven 8h-17h', ['Glycémie', 'NFS', 'TSH'], false, 1.05],
  ['l0', 'Laboratoire Anfa Biologie (fictif)', 'Casablanca', '55 boulevard Test, Anfa', 'Lun-Sam 7h-19h', ['NFS', 'Vitamine D', 'ECBU', 'Albuminurie'], true, 1.15],
  ['p7', 'Laboratoire Détroit (fictif)', 'Tanger', '14 rue Test', 'Lun-Sam 8h-16h', ['Glycémie', 'NFS'], true, 0.95],
  ['l1', 'Laboratoire Agdal Analyses (fictif)', 'Rabat', '9 rue Essai, Agdal', 'Lun-Sam 7h30-18h', pick(BIO, 0, 5), true, 1.1],
  ['l2', 'Laboratoire Hassan Biologie (fictif)', 'Rabat', '30 avenue Démo, Hassan', 'Lun-Ven 8h-17h', ['Glycémie', 'ECBU', 'Coproculture'], false, 1],
  ['l3', 'Laboratoire Guéliz (fictif)', 'Marrakech', '12 avenue Exemple, Guéliz', 'Lun-Sam 8h-18h', pick(BIO, 1, 5), true, 0.95],
  ['l4', 'Laboratoire Atlas Fès (fictif)', 'Fès', '5 rue Modèle, Ville Nouvelle', 'Lun-Sam 7h-17h', pick(BIO, 2, 4), false, 0.9],
  ['l5', 'Laboratoire Souss Analyses (fictif)', 'Agadir', '18 rue Test, Founty', 'Lun-Sam 8h-18h', pick(BIO, 0, 6), true, 1],
  ['l6', 'Laboratoire Hamria (fictif)', 'Meknès', '4 rue Essai, Hamria', 'Lun-Ven 8h-16h', ['Glycémie', 'NFS', 'CRP'], false, 0.9],
  ['l7', 'Laboratoire Oriental (fictif)', 'Oujda', '25 boulevard Démo', 'Lun-Sam 8h-17h', pick(BIO, 3, 4), false, 0.9],
  ['l8', 'Laboratoire Khamsa (fictif)', 'Tétouan', '2 rue Exemple, Centre', 'Lun-Sam 8h-17h', ['Glycémie', 'NFS', 'Bilan lipidique', 'ECBU'], true, 0.95],
  ['l9', 'Laboratoire Gharb (fictif)', 'Kénitra', '16 avenue Test', 'Lun-Ven 7h30-16h', pick(BIO, 1, 4), false, 0.9],
  ['l10', 'Laboratoire Jawhara (fictif)', 'Safi', '8 rue Démo', 'Lun-Sam 8h-16h', ['Glycémie', 'NFS', 'CRP'], false, 0.85],
  ['l11', 'Laboratoire Doukkala (fictif)', 'El Jadida', '10 avenue Modèle', 'Lun-Sam 8h-17h', pick(BIO, 0, 5), true, 0.9],
  ['l12', 'Laboratoire Tadla (fictif)', 'Béni Mellal', '3 rue Essai, Centre', 'Lun-Ven 8h-16h', ['Glycémie', 'NFS', 'TSH'], false, 0.85],
  ['l13', 'Laboratoire Rif (fictif)', 'Nador', '14 boulevard Exemple', 'Lun-Sam 8h-17h', ['Glycémie', 'NFS', 'Bilan lipidique', 'Créatinine'], false, 0.9],
  ['l14', 'Laboratoire Chaouia (fictif)', 'Settat', '6 avenue Test', 'Lun-Ven 8h-16h', pick(BIO, 4, 4), false, 0.85],
].map(([id, name, city, address, hours, names, home, k]) => base(id, 'lab', name, city, address, hours, { services: svc(names, k), home }));

// Centres de radiologie : [id, nom, ville, adresse, horaires, examens, coeff]
const RADIOS = [
  ['p8', 'Centre Imagerie Océan (fictif)', 'Casablanca', '30 boulevard Démo', 'Lun-Sam 8h-19h', ['Radiographie', 'Échographie', 'IRM', 'Scanner'], 1],
  ['r0', 'Centre Imagerie Anfa (fictif)', 'Casablanca', '60 avenue Test, Anfa', 'Lun-Sam 8h-18h', ['Mammographie', 'Panoramique dentaire', 'Densitométrie osseuse', 'Échographie'], 1.1],
  ['p9', 'Centre Radiologie Bouregreg (fictif)', 'Rabat', '9 avenue Exemple', 'Lun-Ven 8h-17h', ['Radiographie', 'Échographie'], 0.9],
  ['r1', 'Imagerie Médicale Agdal (fictif)', 'Rabat', '21 rue Essai, Agdal', 'Lun-Sam 8h-18h', ['IRM', 'Scanner', 'Mammographie'], 1.05],
  ['r2', 'Centre Imagerie Ménara (fictif)', 'Marrakech', '7 avenue Démo, Guéliz', 'Lun-Sam 8h-18h', ['Radiographie', 'Échographie', 'Mammographie', 'Scanner'], 0.95],
  ['r3', 'Centre Radiologie Saïss (fictif)', 'Fès', '13 rue Test, Ville Nouvelle', 'Lun-Ven 8h-17h', ['Radiographie', 'IRM'], 0.9],
  ['r4', 'Centre Imagerie Détroit (fictif)', 'Tanger', '5 boulevard Modèle', 'Lun-Sam 8h-18h', ['Radiographie', 'Échographie', 'Scanner', 'Doppler'], 0.95],
  ['r5', 'Centre Imagerie Souss (fictif)', 'Agadir', '27 avenue Exemple, Founty', 'Lun-Sam 8h-18h', ['Radiographie', 'Échographie', 'IRM'], 1],
  ['r6', 'Centre Radiologie Hamria (fictif)', 'Meknès', '9 rue Démo', 'Lun-Ven 8h-16h', ['Radiographie', 'Échographie', 'Densitométrie osseuse'], 0.85],
  ['r7', 'Centre Imagerie Oriental (fictif)', 'Oujda', '15 avenue Test', 'Lun-Sam 8h-17h', ['Radiographie', 'Scanner', 'Échographie'], 0.9],
  ['r8', 'Centre Radiologie Khamsa (fictif)', 'Tétouan', '4 rue Essai', 'Lun-Sam 8h-17h', ['Radiographie', 'Échographie', 'Panoramique dentaire'], 0.9],
  ['r9', 'Centre Imagerie Gharb (fictif)', 'Kénitra', '18 boulevard Exemple', 'Lun-Ven 8h-16h', ['Radiographie', 'Échographie', 'Doppler'], 0.85],
  ['r10', 'Centre Radiologie Jawhara (fictif)', 'Safi', '2 avenue Modèle', 'Lun-Sam 8h-16h', ['Radiographie', 'Échographie'], 0.85],
  ['r11', 'Centre Imagerie Doukkala (fictif)', 'El Jadida', '11 rue Démo', 'Lun-Sam 8h-17h', ['Radiographie', 'Échographie', 'Scanner', 'Mammographie'], 0.9],
  ['r12', 'Centre Radiologie Tadla (fictif)', 'Béni Mellal', '6 avenue Test', 'Lun-Ven 8h-16h', ['Radiographie', 'Échographie'], 0.85],
  ['r13', 'Centre Imagerie Rif (fictif)', 'Nador', '9 boulevard Essai', 'Lun-Sam 8h-17h', ['Radiographie', 'Échographie', 'IRM'], 0.9],
  ['r14', 'Centre Radiologie Chaouia (fictif)', 'Settat', '12 rue Exemple', 'Lun-Ven 8h-16h', ['Radiographie', 'Échographie', 'Panoramique dentaire'], 0.85],
].map(([id, name, city, address, hours, names, k]) => base(id, 'radio', name, city, address, hours, { services: svc(names, k) }));

export const DEMO = {
  providers: [...DOCTORS, ...CABINETS, ...LABS, ...RADIOS],
  users: [
    { id: 'u1', role: 'doctor', nom: 'Fictive', prenom: 'Amina', email: 'medecin@demo.ma', password: 'demo1234', providerId: 'p1', profile: {} },
    { id: 'u2', role: 'lab', nom: 'Responsable', prenom: 'Horizon', email: 'labo@demo.ma', password: 'demo1234', providerId: 'p5', profile: {} },
    { id: 'u3', role: 'radio', nom: 'Responsable', prenom: 'Océan', email: 'radio@demo.ma', password: 'demo1234', providerId: 'p8', profile: {} },
    { id: 'u4', role: 'patient', nom: 'Patient', prenom: 'Démo', email: 'patient@demo.ma', password: 'demo1234', naissance: '1990-01-01', sexe: 'Femme', tel: '0600000000', profile: {} },
    { id: 'u5', role: 'cabinet', nom: 'Responsable', prenom: 'Anfa', email: 'cabinet@demo.ma', password: 'demo1234', providerId: 'c1', profile: {} },
  ],
  requests: [
    { id: 'r1', patientId: 'u4', patientName: 'Démo Patient', patientTel: '0600000000', providerId: 'p1', kind: 'rdv', service: 'Cardiologie', date: '2026-11-03', time: '10:00', motif: 'Contrôle (exemple fictif)', status: 'Acceptée', share: false },
    { id: 'r2', patientId: 'u4', patientName: 'Démo Patient', patientTel: '0600000000', providerId: 'p5', kind: 'analyse', service: 'Glycémie', mode: 'Au laboratoire', date: '2026-11-05', time: '09:00', status: 'En attente', share: false },
    { id: 'r3', patientId: 'u4', patientName: 'Démo Patient', patientTel: '0600000000', providerId: 'p8', kind: 'radio', service: 'Radiographie', date: '2026-10-28', time: '14:00', status: 'Refusée', reason: 'Créneau complet (exemple)', share: false },
  ],
};
