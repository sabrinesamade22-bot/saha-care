// Catalogues de référence utilisés par les formulaires et les filtres de recherche.
export const SPECS = {
  Cardiologie: ['Hypertension', 'Infarctus', 'Arythmie'], Dermatologie: ['Eczéma', 'Psoriasis', 'Acné'],
  Endocrinologie: ['Diabète', 'Thyroïde', 'Obésité'], Pneumologie: ['Asthme', 'Bronchite chronique'],
  'Gastro-entérologie': ['Gastrite', 'Colopathie', 'Reflux'], Neurologie: ['Migraine', 'Épilepsie'],
  Orthopédie: ['Fracture', 'Arthrose', 'Hernie discale'],
};
// Spécialités proposables par un médecin ou un cabinet (SPECS + spécialités courantes).
export const SPECIALTIES = [...Object.keys(SPECS), 'Médecine générale', 'Pédiatrie', 'Gynécologie-obstétrique', 'Ophtalmologie', 'ORL', 'Urologie', 'Psychiatrie', 'Rhumatologie', 'Médecine dentaire'];

// Analyses : un « type » peut être une catégorie (ex. Analyse sanguine) ou une analyse précise.
export const ANALYSE_GROUPS = {
  'Analyse sanguine': ['Glycémie', 'NFS', 'Bilan lipidique', 'TSH', 'Bilan hépatique', 'Créatinine', 'CRP', 'Ferritine', 'Vitamine D'],
  'Analyse d’urine': ['ECBU', 'Albuminurie'],
  'Analyse microbiologique': ['Prélèvement de gorge', 'Coproculture'],
};
// Examens de radiologie.
export const EXAMS = ['Radiographie', 'Échographie', 'Scanner', 'IRM', 'Mammographie', 'Panoramique dentaire', 'Densitométrie osseuse', 'Doppler'];
