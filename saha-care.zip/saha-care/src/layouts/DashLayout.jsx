import { LogOut, Bell } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { ROLE_LABEL, DemoNotice } from '../components/ui.jsx';
import Logo from '../components/Logo.jsx';
export default function DashLayout({ tabs, tab, setTab, unread, flash, children }) {
  const { user, logout } = useAuth();
  return <div className="dash">
    <aside><Link to="/" className="logo" aria-label="Saha-Care, accueil"><Logo size={30} /></Link>
      <div className="me"><b>{user.prenom} {user.nom}</b><small>{ROLE_LABEL[user.role]}</small></div>
      {tabs.map((t) => <button key={t.k} className={tab === t.k ? 'on' : ''} onClick={() => setTab(t.k)}>{t.icon}{t.label}{t.k === 'notifs' && unread > 0 && <i className="dot">{unread}</i>}</button>)}
      <button onClick={logout} className="out"><LogOut size={18} />Se déconnecter</button></aside>
    <main><DemoNotice />{flash && <div className="flash">{flash}</div>}{children}</main></div>;
}
export const Notifs = ({ list, onRead }) => <section><div className="row"><h2><Bell size={20} /> Notifications</h2>{list.some((n) => !n.read) && <button className="btn sm" onClick={onRead}>Tout marquer comme lu</button>}</div>
  {list.length === 0 ? <div className="empty"><p>Aucune notification pour le moment.</p></div> : [...list].reverse().map((n) => <div key={n.id} className={'card note' + (n.read ? '' : ' new')}>{n.text}<small>{new Date(n.date).toLocaleString('fr-FR')}</small></div>)}</section>;
