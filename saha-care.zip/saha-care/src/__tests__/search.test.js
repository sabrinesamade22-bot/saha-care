import { describe, it, expect, beforeEach } from 'vitest';
import { DEMO } from '../data/demo.js';
import { CITIES } from '../data/cities.js';
import { db, DATA_VERSION } from '../services/store.js';
import { searchProviders, norm } from '../services/search.js';

const P = DEMO.providers;
const ids = (r) => r.map((p) => p.id).sort().join(',');
const MAIN = ['Casablanca', 'Rabat', 'Marrakech', 'Fès', 'Tanger', 'Agadir', 'Meknès', 'Oujda', 'Tétouan', 'Kénitra', 'Safi', 'El Jadida', 'Béni Mellal', 'Nador', 'Settat'];

describe('médecins', () => {
  it('Casablanca + Cardiologie : uniquement des cardiologues de Casablanca', () => {
    const r = searchProviders(P, { kind: 'rdv', city: 'Casablanca', term: 'Cardiologie' });
    expect(r.length).toBeGreaterThanOrEqual(3);
    r.forEach((p) => { expect(p.city).toBe('Casablanca'); expect(p.specialties).toContain('Cardiologie'); expect(['doctor', 'cabinet']).toContain(p.type); });
  });
  it('changer de ville (Rabat) change les résultats', () => {
    const cas = searchProviders(P, { kind: 'rdv', city: 'Casablanca', term: 'Cardiologie' });
    const rab = searchProviders(P, { kind: 'rdv', city: 'Rabat', term: 'Cardiologie' });
    expect(rab.length).toBeGreaterThan(0); rab.forEach((p) => expect(p.city).toBe('Rabat')); expect(ids(rab)).not.toBe(ids(cas));
  });
  it('changer de spécialité change les résultats', () => {
    const a = searchProviders(P, { kind: 'rdv', city: 'Casablanca', term: 'Cardiologie' });
    const b = searchProviders(P, { kind: 'rdv', city: 'Casablanca', term: 'Dermatologie' });
    expect(b.length).toBeGreaterThan(0); expect(ids(a)).not.toBe(ids(b)); b.forEach((p) => expect(p.specialties).toContain('Dermatologie'));
  });
  it('un cabinet multi-spécialités apparaît pour chacune de ses spécialités', () => {
    expect(searchProviders(P, { kind: 'rdv', city: 'Casablanca', term: 'Médecine générale' }).map((p) => p.id)).toContain('c1');
    expect(searchProviders(P, { kind: 'rdv', city: 'Casablanca', term: 'Cardiologie' }).map((p) => p.id)).toContain('c1');
  });
  it('recherche par nom (sans accents ni casse) et sans critère', () => {
    expect(searchProviders(P, { kind: 'rdv', name: 'amina' }).map((p) => p.id)).toEqual(['p1']);
    expect(searchProviders(P, { kind: 'rdv', name: 'ANFA' }).length).toBeGreaterThan(0);
    expect(searchProviders(P, { kind: 'rdv' }).length).toBeGreaterThan(30);
  });
  it('les médecins ne remontent pas dans la recherche labo/radio', () => {
    expect(searchProviders(P, { kind: 'analyse' }).every((p) => p.type === 'lab')).toBe(true);
    expect(searchProviders(P, { kind: 'radio' }).every((p) => p.type === 'radio')).toBe(true);
  });
});

describe('laboratoires', () => {
  it('Casablanca + Analyse sanguine / Rabat + Analyse sanguine', () => {
    const cas = searchProviders(P, { kind: 'analyse', city: 'Casablanca', term: 'Analyse sanguine' });
    const rab = searchProviders(P, { kind: 'analyse', city: 'Rabat', term: 'Analyse sanguine' });
    expect(cas.length).toBeGreaterThanOrEqual(2); expect(rab.length).toBeGreaterThanOrEqual(1);
    cas.forEach((p) => expect(p.city).toBe('Casablanca')); rab.forEach((p) => expect(p.city).toBe('Rabat')); expect(ids(cas)).not.toBe(ids(rab));
  });
  it('analyse précise : seuls les labos qui la proposent', () => {
    const r = searchProviders(P, { kind: 'analyse', city: 'Casablanca', term: 'TSH' });
    expect(r.map((p) => p.id)).toEqual(['p6']); r.forEach((p) => expect(p.services.some((s) => s.name === 'TSH')).toBe(true));
  });
  it('une analyse d’urine ne renvoie pas les labos sans urine', () => {
    const r = searchProviders(P, { kind: 'analyse', city: 'Casablanca', term: 'Analyse d’urine' });
    expect(r.map((p) => p.id)).toEqual(['l0']);
  });
  it('filtre prélèvement à domicile', () => {
    const r = searchProviders(P, { kind: 'analyse', city: 'Casablanca', home: true });
    expect(r.length).toBeGreaterThan(0); r.forEach((p) => expect(p.home).toBe(true));
  });
});

describe('radiologie', () => {
  it('Rabat + IRM, Casablanca + IRM : différents et filtrés', () => {
    const rab = searchProviders(P, { kind: 'radio', city: 'Rabat', term: 'IRM' });
    const cas = searchProviders(P, { kind: 'radio', city: 'Casablanca', term: 'IRM' });
    expect(rab.map((p) => p.id)).toEqual(['r1']); expect(cas.map((p) => p.id)).toEqual(['p8']);
  });
  it('les résultats varient selon le type d’examen', () => {
    const irm = searchProviders(P, { kind: 'radio', city: 'Casablanca', term: 'IRM' });
    const mam = searchProviders(P, { kind: 'radio', city: 'Casablanca', term: 'Mammographie' });
    expect(ids(irm)).not.toBe(ids(mam)); mam.forEach((p) => expect(p.services.some((s) => s.name === 'Mammographie')).toBe(true));
  });
  it('examen absent de la ville → liste vide, pas de repli sur une autre liste', () => {
    expect(searchProviders(P, { kind: 'radio', city: 'Safi', term: 'IRM' })).toEqual([]);
  });
});

describe('villes', () => {
  it('la liste contient les 15 villes demandées', () => { MAIN.forEach((c) => expect(CITIES).toContain(c)); expect(new Set(CITIES).size).toBe(CITIES.length); });
  it.each(MAIN)('%s : au moins un médecin, un laboratoire et un centre de radiologie', (city) => {
    expect(searchProviders(P, { kind: 'rdv', city }).length).toBeGreaterThan(0);
    expect(searchProviders(P, { kind: 'analyse', city }).length).toBeGreaterThan(0);
    expect(searchProviders(P, { kind: 'radio', city }).length).toBeGreaterThan(0);
  });
  it('tolère accents, casse et tirets', () => {
    expect(norm('Béni Mellal')).toBe(norm('beni-mellal'));
    expect(searchProviders(P, { kind: 'rdv', city: 'beni mellal' }).length).toBeGreaterThan(0);
    expect(searchProviders(P, { kind: 'rdv', city: 'FES' }).length).toBeGreaterThan(0);
  });
});

describe('intégrité des données de démonstration', () => {
  it('toutes les fiches sont marquées démo et jamais « vérifiées »', () => { expect(P.every((p) => p.demo === true && p.verified === false)).toBe(true); });
  it('identifiants uniques et téléphones factices', () => { expect(new Set(P.map((p) => p.id)).size).toBe(P.length); expect(P.every((p) => p.phone.startsWith('05 00 00 00'))).toBe(true); });
  it('les comptes démo pointent vers des fiches existantes', () => { DEMO.users.filter((u) => u.providerId).forEach((u) => expect(P.some((p) => p.id === u.providerId)).toBe(true)); });
});

describe('cause racine : ancien LocalStorage', () => {
  beforeEach(() => localStorage.clear());
  it('une base déjà « seeded » mais vide est régénérée', () => {
    localStorage.setItem('sahacare_seeded', '1'); localStorage.setItem('sahacare_providers', '[]'); localStorage.setItem('sahacare_users', '[]');
    db.init();
    expect(db.all('providers').length).toBe(P.length);
    expect(searchProviders(db.all('providers'), { kind: 'rdv', city: 'Casablanca', term: 'Cardiologie' }).length).toBeGreaterThan(0);
  });
  it('conserve les fiches et comptes créés par les utilisateurs', () => {
    localStorage.setItem('sahacare_seeded', '1');
    localStorage.setItem('sahacare_providers', JSON.stringify([{ id: 'mine', type: 'cabinet', name: 'Mon cabinet', city: 'casablanca', specialty: 'Cardiologie', services: [] }, { id: 'p1', demo: true, name: 'ancien' }]));
    localStorage.setItem('sahacare_users', JSON.stringify([{ id: 'x1', email: 'a@b.ma', role: 'cabinet', providerId: 'mine' }]));
    db.init();
    const prov = db.all('providers');
    expect(prov.find((p) => p.id === 'mine')).toBeTruthy(); expect(prov.find((p) => p.id === 'p1').name).not.toBe('ancien');
    expect(db.all('users').some((u) => u.id === 'x1')).toBe(true); expect(db.all('users').some((u) => u.id === 'u4')).toBe(true);
    // une fiche ancienne (champ `specialty`, ville en minuscules) reste trouvable
    expect(searchProviders(prov, { kind: 'rdv', city: 'Casablanca', term: 'Cardiologie' }).map((p) => p.id)).toContain('mine');
  });
  it('n’écrase pas les données si la version est à jour', () => {
    db.init(); db.add('providers', { id: 'zz', type: 'lab', name: 'Nouveau', city: 'Rabat', services: [] }); db.init();
    expect(db.all('providers').some((p) => p.id === 'zz')).toBe(true); expect(DATA_VERSION).toBeGreaterThanOrEqual(2);
  });
});
