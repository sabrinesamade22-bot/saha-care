import { describe, it, expect, beforeEach, vi } from 'vitest';
import { render, screen, within, cleanup } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router-dom';
import App from '../App.jsx';
import { AuthProvider } from '../context/AuthContext.jsx';
import { db } from '../services/store.js';

vi.mock('../services/pdf.js', () => ({ dossierPDF: vi.fn() }));
const mount = (path = '/') => render(<MemoryRouter initialEntries={[path]}><AuthProvider><App /></AuthProvider></MemoryRouter>);
const asPatient = () => { db.init(); db.setSession('u4'); };
const openTab = async (ue, name) => ue.click(screen.getByRole('button', { name: new RegExp('^' + name) }));
const cards = () => screen.queryAllByRole('article');
const names = () => cards().map((c) => within(c).getByRole('heading', { level: 3 }).textContent);

beforeEach(() => { cleanup(); localStorage.clear(); });

describe('recherche de médecins', () => {
  it('Casablanca + Cardiologie puis Rabat : les résultats changent', async () => {
    asPatient(); const ue = userEvent.setup(); mount('/espace'); await openTab(ue, 'Médecins');
    await ue.selectOptions(screen.getByLabelText('Ville'), 'Casablanca'); await ue.selectOptions(screen.getByLabelText('Spécialité'), 'Cardiologie');
    const cas = names(); expect(cas.length).toBeGreaterThanOrEqual(3); expect(cas).toContain('Dr Amina Fictive');
    cards().forEach((c) => { expect(c.textContent).toMatch(/Casablanca/); expect(c.textContent).toMatch(/Cardiologie/); expect(c.textContent).toMatch(/Donnée de démonstration/); expect(c.textContent).not.toMatch(/Vérifié/); });
    await ue.selectOptions(screen.getByLabelText('Ville'), 'Rabat');
    const rab = names(); expect(rab.length).toBeGreaterThan(0); expect(rab).not.toEqual(cas); cards().forEach((c) => expect(c.textContent).toMatch(/Rabat/));
    await ue.selectOptions(screen.getByLabelText('Spécialité'), 'Dermatologie'); expect(names()).toContain('Dr Karim Exemple');
  });
  it('une fiche affiche cabinet, adresse, téléphone, horaires et les boutons', async () => {
    asPatient(); const ue = userEvent.setup(); mount('/espace'); await openTab(ue, 'Médecins');
    await ue.type(screen.getByLabelText('Nom du médecin ou du cabinet'), 'amina');
    const [c] = cards(); expect(cards()).toHaveLength(1);
    expect(c.textContent).toMatch(/Cabinet médical Maarif/); expect(c.textContent).toMatch(/rue Exemple/); expect(c.textContent).toMatch(/05 00 00 00/); expect(c.textContent).toMatch(/Lun-Ven/);
    await ue.click(within(c).getByRole('button', { name: 'Voir les détails' })); const dlg = screen.getByRole('dialog');
    expect(dlg.textContent).toMatch(/Dr Amina Fictive/); await ue.click(within(dlg).getByRole('button', { name: 'Prendre rendez-vous' }));
    expect(screen.queryByRole('dialog')).toBeNull(); expect(screen.getByText(/Demande auprès de Dr Amina Fictive/)).toBeTruthy();
  });
  it('aucun résultat : message clair et bouton de réinitialisation', async () => {
    asPatient(); const ue = userEvent.setup(); mount('/espace'); await openTab(ue, 'Médecins');
    await ue.selectOptions(screen.getByLabelText('Ville'), 'Safi'); await ue.selectOptions(screen.getByLabelText('Spécialité'), 'Neurologie');
    expect(cards()).toHaveLength(0); expect(screen.getByText(/Aucun résultat/)).toBeTruthy();
    await ue.click(screen.getByRole('button', { name: 'Réinitialiser les filtres' })); expect(cards().length).toBeGreaterThan(10);
  });
});

describe('laboratoires et radiologie', () => {
  it('Casablanca + Analyse sanguine, puis Rabat', async () => {
    asPatient(); const ue = userEvent.setup(); mount('/espace'); await openTab(ue, 'Analyses biologiques');
    await ue.selectOptions(screen.getByLabelText('Ville'), 'Casablanca'); await ue.selectOptions(screen.getByLabelText('Type d’analyse'), 'Analyse sanguine');
    const cas = names(); expect(cas.length).toBeGreaterThanOrEqual(2); cards().forEach((c) => expect(c.textContent).toMatch(/Casablanca/));
    expect(cards()[0].textContent).toMatch(/MAD/); expect(within(cards()[0]).getByRole('link', { name: /Contacter/ }).getAttribute('href')).toMatch(/^tel:/);
    await ue.selectOptions(screen.getByLabelText('Ville'), 'Rabat'); expect(names()).not.toEqual(cas); cards().forEach((c) => expect(c.textContent).toMatch(/Rabat/));
  });
  it('Radiologie : Rabat + IRM puis Casablanca + IRM, puis Mammographie', async () => {
    asPatient(); const ue = userEvent.setup(); mount('/espace'); await openTab(ue, 'Examens radiologiques');
    await ue.selectOptions(screen.getByLabelText('Ville'), 'Rabat'); await ue.selectOptions(screen.getByLabelText('Type d’examen'), 'IRM');
    expect(names()).toEqual(['Imagerie Médicale Agdal (fictif)']);
    await ue.selectOptions(screen.getByLabelText('Ville'), 'Casablanca'); expect(names()).toEqual(['Centre Imagerie Océan (fictif)']);
    await ue.selectOptions(screen.getByLabelText('Type d’examen'), 'Mammographie'); expect(names()).toEqual(['Centre Imagerie Anfa (fictif)']);
  });
});

describe('profil médical : « Rien à signaler »', () => {
  it('se coche, s’enregistre sans autre champ, puis se modifie', async () => {
    asPatient(); const ue = userEvent.setup(); mount('/espace');
    const box = screen.getByRole('checkbox', { name: /Rien à signaler/ }); expect(box.checked).toBe(false); expect(screen.getByText('Antécédents médicaux')).toBeTruthy();
    await ue.click(box); expect(box.checked).toBe(true); expect(screen.getByText(/Vous avez indiqué « Rien à signaler »/)).toBeTruthy(); expect(screen.getByText('Antécédents chirurgicaux')).toBeTruthy();
    await ue.click(screen.getByRole('button', { name: 'Enregistrer mon dossier médical' }));
    expect(db.all('users').find((u) => u.id === 'u4').profile.aucunAnt).toBe(true);
    expect(screen.getByText(/Rien à signaler \(aucun antécédent médical\)/)).toBeTruthy();
    await ue.click(screen.getByRole('button', { name: 'Mettre à jour mon dossier' }));
    const again = screen.getByRole('checkbox', { name: /Rien à signaler/ }); expect(again.checked).toBe(true);
    await ue.click(again); expect(again.checked).toBe(false); expect(screen.queryByText(/Vous avez indiqué/)).toBeNull();
    await ue.click(screen.getByRole('button', { name: 'Enregistrer mon dossier médical' })); expect(db.all('users').find((u) => u.id === 'u4').profile.aucunAnt).toBe(false);
  });
  it('demande confirmation avant d’effacer des antécédents saisis', async () => {
    db.init(); db.upd('users', 'u4', { profile: { antMed: [{ spec: 'Cardiologie', detail: 'Hypertension' }], antChir: [] } }); db.setSession('u4');
    const ue = userEvent.setup(); const spy = vi.spyOn(window, 'confirm').mockReturnValue(false); mount('/espace');
    const box = screen.getByRole('checkbox', { name: /Rien à signaler/ }); await ue.click(box); expect(spy).toHaveBeenCalled(); expect(box.checked).toBe(false);
    spy.mockReturnValue(true); await ue.click(box); expect(box.checked).toBe(true); spy.mockRestore();
  });
});

describe('inscription : « Cabinet médical »', () => {
  it('remplace « Médecin », crée la fiche et le cabinet devient trouvable', async () => {
    db.init(); const ue = userEvent.setup(); mount('/inscription');
    expect(screen.queryByRole('button', { name: /^Médecin$/ })).toBeNull(); expect(screen.queryByRole('button', { name: /indépendant/i })).toBeNull();
    await ue.click(screen.getByRole('button', { name: 'Cabinet médical' }));
    await ue.type(screen.getByLabelText('Nom du cabinet médical *'), 'Cabinet Test Zéro'); await ue.type(screen.getByLabelText('Nom du responsable *'), 'Alami'); await ue.type(screen.getByLabelText('Prénom *'), 'Sara');
    await ue.type(screen.getByLabelText(/Médecins du cabinet/), 'Dr A\nDr B'); await ue.selectOptions(screen.getByLabelText('Ville *'), 'Fès');
    await ue.type(screen.getByLabelText('Adresse complète *'), '1 rue Test'); await ue.type(screen.getByLabelText('Horaires de consultation'), 'Lun-Ven 9h-17h');
    await ue.type(screen.getByLabelText('Adresse e-mail *'), 'nouveau@cabinet.ma'); await ue.type(screen.getByLabelText('Téléphone *'), '0500000099'); await ue.type(screen.getByLabelText('Mot de passe *'), 'secret1');
    await ue.click(screen.getByRole('button', { name: 'Créer mon compte' })); expect(screen.getByText(/spécialité proposée/)).toBeTruthy();
    await ue.click(screen.getByRole('button', { name: 'Ophtalmologie' })); await ue.click(screen.getByRole('button', { name: 'Créer mon compte' }));
    const u = db.all('users').find((x) => x.email === 'nouveau@cabinet.ma'); expect(u.role).toBe('cabinet');
    const p = db.all('providers').find((x) => x.id === u.providerId);
    expect(p).toMatchObject({ type: 'cabinet', name: 'Cabinet Test Zéro', city: 'Fès', specialties: ['Ophtalmologie'], doctors: ['Dr A', 'Dr B'], hours: 'Lun-Ven 9h-17h', verified: false });
    expect(await screen.findByText('Demandes reçues')).toBeTruthy(); await openTab(ue, 'Mon cabinet'); expect(screen.getByText('Ma fiche de cabinet')).toBeTruthy();
    cleanup(); db.setSession('u4'); mount('/espace'); await openTab(ue, 'Médecins');
    await ue.selectOptions(screen.getByLabelText('Ville'), 'Fès'); await ue.selectOptions(screen.getByLabelText('Spécialité'), 'Ophtalmologie');
    expect(names()).toEqual(['Cabinet Test Zéro']); expect(cards()[0].textContent).toMatch(/En attente de vérification/);
  });
  it('un médecin de cabinet existant garde son espace professionnel', async () => {
    db.init(); db.setSession('u1'); mount('/espace'); expect(screen.getByText('Demandes reçues')).toBeTruthy();
  });
  it('le compte démo cabinet accède à sa fiche', async () => {
    db.init(); db.setSession('u5'); const ue = userEvent.setup(); mount('/espace'); await openTab(ue, 'Mon cabinet');
    expect(screen.getByDisplayValue('Cabinet Médical Anfa (fictif)')).toBeTruthy(); expect(screen.getByRole('button', { name: 'Cardiologie' }).getAttribute('aria-pressed')).toBe('true');
  });
});
