import { createContext, useContext, useState } from 'react';
import { db, uid } from '../services/store.js';
const Ctx = createContext();
export const useAuth = () => useContext(Ctx);
const lines = (t) => (t || '').split(/[\n,;]+/).map((x) => x.trim()).filter(Boolean);
export function AuthProvider({ children }) {
  db.init();
  const [sid, setSid] = useState(db.session());
  const [, setTick] = useState(0);
  const refresh = () => setTick((t) => t + 1);
  const user = db.all('users').find((u) => u.id === sid) || null;
  const login = (email, pw) => {
    const u = db.all('users').find((x) => x.email === email.trim().toLowerCase() && x.password === pw);
    if (!u) return { error: 'E-mail ou mot de passe incorrect.' };
    db.setSession(u.id); setSid(u.id); return {};
  };
  const logout = () => { db.setSession(null); setSid(null); };
  const register = (d) => {
    const email = d.email.trim().toLowerCase();
    if (db.all('users').some((x) => x.email === email)) return { error: 'Un compte existe déjà avec cette adresse e-mail.' };
    const u = { id: uid(), role: d.role, nom: d.nom, prenom: d.prenom, email, tel: d.tel, password: d.password, naissance: d.naissance, sexe: d.sexe, profile: {} };
    if (d.role !== 'patient') {
      u.providerId = uid();
      const isCab = d.role === 'cabinet';
      db.add('providers', { id: u.providerId, type: d.role, name: d.etab, city: d.ville, specialties: isCab ? d.specialites || [] : [], doctors: isCab ? lines(d.medecins) : [], cabinet: '', manager: isCab ? `${d.prenom} ${d.nom}` : '', address: d.adresse, phone: d.tel, hours: d.horaires || '', description: d.description || '', diplomes: d.diplomes || '', infos: d.infos || '', home: false, services: [], slots: ['09:00', '10:00', '11:00', '14:00', '15:00'], photo: '', verified: false });
    }
    db.add('users', u); db.setSession(u.id); setSid(u.id); return {};
  };
  return <Ctx.Provider value={{ user, login, logout, register, refresh }}>{children}</Ctx.Provider>;
}
