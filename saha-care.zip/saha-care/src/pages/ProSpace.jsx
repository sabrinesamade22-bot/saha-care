import { useState } from 'react';
import { ClipboardList, Building2, Bell, Download, Calendar } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import DashLayout, { Notifs } from '../layouts/DashLayout.jsx';
import { Field, Badge, Empty, Stat, KIND_LABEL } from '../components/ui.jsx';
import { db } from '../services/store.js';
import { dossierPDF } from '../services/pdf.js';
import { CITIES } from '../data/cities.js';
import { SPECIALTIES } from '../data/catalog.js';
import { provSpecs } from '../services/search.js';
function Requests({ reqs, flash, refresh }) {
  const [note, setNote] = useState({});
  const decide = (r, status, extra = {}) => { db.upd('requests', r.id, { status, ...extra }); db.notify(r.patientId, `Votre demande (${r.service}, ${r.date}) a été ${status === 'Acceptée' ? 'acceptée' : 'refusée'}.${extra.reason ? ' Motif : ' + extra.reason : ''}`); refresh(); flash(`Demande ${status === 'Acceptée' ? 'acceptée' : 'refusée'}. Le patient a été notifié.`); };
  const propose = (r) => { if (!note[r.id]) return flash('Saisissez un créneau à proposer.'); db.upd('requests', r.id, { proposal: note[r.id] }); db.notify(r.patientId, `Un autre créneau vous est proposé : ${note[r.id]}.`); refresh(); flash('Créneau proposé au patient.'); };
  const next = reqs.filter((r) => r.status === 'Acceptée').sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
  return <section><h2>Demandes reçues</h2><div className="stats">{['En attente', 'Acceptée', 'Refusée', 'Annulée'].map((s) => <Stat key={s} n={reqs.filter((r) => r.status === s).length} label={s} />)}</div>
    {reqs.length === 0 ? <Empty icon={<ClipboardList />} text="Aucune demande reçue pour le moment." /> : <div className="tw"><table><thead><tr><th>Patient</th><th>Type</th><th>Détails</th><th>Statut</th><th>Actions</th></tr></thead><tbody>
      {[...reqs].reverse().map((r) => <tr key={r.id}><td>{r.patientName}{r.status === 'Acceptée' && <small>Tél. {r.patientTel}</small>}</td><td>{KIND_LABEL[r.kind]}<small>{r.service}</small></td>
        <td>{r.date} {r.time}{r.mode && <small>{r.mode}{r.status === 'Acceptée' && r.adresse ? ' — ' + r.adresse : ''}</small>}{r.motif && <small>Motif : {r.motif}</small>}{r.notes && <small>{r.notes}</small>}
          {r.share && r.dossier ? <button className="btn sm" onClick={() => dossierPDF(r.dossier.u, r.dossier.p)}><Download size={14} /> Dossier PDF partagé</button> : r.kind === 'rdv' && <small>Dossier non partagé</small>}</td>
        <td><Badge s={r.status} />{r.reason && <small>{r.reason}</small>}{r.proposal && <small>Proposé : {r.proposal}</small>}</td>
        <td>{r.status === 'En attente' && <div className="act"><button className="btn sm" onClick={() => decide(r, 'Acceptée')}>Accepter</button>
          <input placeholder="Raison du refus (facultatif)" value={note['r' + r.id] || ''} onChange={(e) => setNote({ ...note, ['r' + r.id]: e.target.value })} /><button className="btn sm ghost" onClick={() => decide(r, 'Refusée', { reason: note['r' + r.id] })}>Refuser</button>
          <input placeholder="Autre créneau (ex : 12/11 à 10h)" value={note[r.id] || ''} onChange={(e) => setNote({ ...note, [r.id]: e.target.value })} /><button className="btn sm ghost" onClick={() => propose(r)}>Proposer</button></div>}</td></tr>)}</tbody></table></div>}
    <h3><Calendar size={18} /> Prochains rendez-vous</h3>{next.length === 0 ? <Empty text="Aucun rendez-vous accepté." /> : next.map((r) => <div className="card" key={r.id}><b>{r.date} à {r.time}</b> — {r.patientName} ({r.service})</div>)}</section>;
}
function Etab({ p, flash, refresh }) {
  const [f, setF] = useState({ ...p, slotsText: p.slots.join(', '), specialties: provSpecs(p), doctorsText: (p.doctors || []).join('\n') });
  const hasPrices = p.type === 'lab' || p.type === 'radio'; const isMed = p.type === 'cabinet' || p.type === 'doctor';
  const b = (k) => ({ value: f[k] || '', onChange: (e) => setF({ ...f, [k]: e.target.value }) });
  const setS = (i, k, v) => setF({ ...f, services: f.services.map((s, j) => (j === i ? { ...s, [k]: v } : s)) });
  const toggleSpec = (x) => setF({ ...f, specialties: f.specialties.includes(x) ? f.specialties.filter((y) => y !== x) : [...f.specialties, x] });
  const save = (e) => {
    e.preventDefault();
    if (isMed && !f.specialties.length) return flash('Sélectionnez au moins une spécialité.');
    const { slotsText, doctorsText, specialty, ...rest } = f;
    db.upd('providers', p.id, { ...rest, specialties: isMed ? f.specialties : [], doctors: p.type === 'cabinet' ? doctorsText.split(/[\n,;]+/).map((x) => x.trim()).filter(Boolean) : p.doctors || [], services: f.services.filter((x) => x.name).map((x) => ({ ...x, price: +x.price || 0 })), slots: slotsText.split(',').map((x) => x.trim()).filter(Boolean) });
    refresh(); flash('Informations enregistrées.');
  };
  const badge = p.demo ? <span className="tag tag-demo">Compte de démonstration</span> : p.verified ? <span className="badge b-acceptee">Compte vérifié</span> : <span className="badge b-enattente">En attente de vérification</span>;
  return <section><h2>{p.type === 'cabinet' ? 'Ma fiche de cabinet' : 'Mon établissement'}</h2>{badge}
    <form onSubmit={save}><div className="card fg"><Field label={p.type === 'cabinet' ? 'Nom du cabinet médical' : 'Nom'}><input {...b('name')} required /></Field>
      <Field label="Ville"><select {...b('city')} required><option value="">Choisir une ville…</option>{[...new Set([...(f.city ? [f.city] : []), ...CITIES])].map((c) => <option key={c}>{c}</option>)}</select></Field>
      <Field label="Adresse"><input {...b('address')} /></Field><Field label="Téléphone"><input {...b('phone')} /></Field><Field label={isMed ? 'Horaires de consultation' : 'Horaires'}><input {...b('hours')} /></Field>
      {p.type === 'cabinet' && <Field label="Médecins du cabinet (un par ligne)"><textarea value={f.doctorsText} onChange={(e) => setF({ ...f, doctorsText: e.target.value })} /></Field>}
      <Field label="Description"><textarea {...b('description')} /></Field>
      <Field label="Créneaux disponibles (séparés par des virgules)"><input value={f.slotsText} onChange={(e) => setF({ ...f, slotsText: e.target.value })} /></Field>
      {p.type === 'lab' && <label className="chk"><input type="checkbox" checked={!!f.home} onChange={(e) => setF({ ...f, home: e.target.checked })} /> Prélèvement à domicile</label>}</div>
      {isMed && <div className="card"><h4>Spécialités médicales proposées</h4><div className="chips">{SPECIALTIES.map((x) => <button type="button" key={x} aria-pressed={f.specialties.includes(x)} className={'chip' + (f.specialties.includes(x) ? ' on' : '')} onClick={() => toggleSpec(x)}>{x}</button>)}</div></div>}
      {hasPrices && <div className="card"><h4>{p.type === 'lab' ? 'Analyses proposées' : 'Examens proposés'} et prix indicatifs (MAD)</h4>
        {f.services.map((s, i) => <div className="fg" key={i}><input placeholder="Nom" value={s.name} onChange={(e) => setS(i, 'name', e.target.value)} /><input type="number" placeholder="Prix" value={s.price} onChange={(e) => setS(i, 'price', e.target.value)} /><button type="button" className="btn sm ghost" onClick={() => setF({ ...f, services: f.services.filter((_, j) => j !== i) })}>Retirer</button></div>)}
        <button type="button" className="btn sm" onClick={() => setF({ ...f, services: [...f.services, { name: '', price: '' }] })}>Ajouter</button></div>}
      <button className="btn big">Enregistrer</button></form></section>;
}
export default function ProSpace() {
  const { user: u, refresh } = useAuth(); const [tab, setTab] = useState('demandes'); const [msg, setMsg] = useState('');
  const flash = (m) => { setMsg(m); setTimeout(() => setMsg(''), 6000); };
  const p = db.all('providers').find((x) => x.id === u.providerId);
  const reqs = db.all('requests').filter((r) => r.providerId === u.providerId); const notifs = db.all('notifs').filter((n) => n.userId === u.id);
  const tabs = [{ k: 'demandes', label: 'Demandes', icon: <ClipboardList size={18} /> }, { k: 'etab', label: u.role === 'cabinet' ? 'Mon cabinet' : 'Mon établissement', icon: <Building2 size={18} /> }, { k: 'notifs', label: 'Notifications', icon: <Bell size={18} /> }];
  return <DashLayout tabs={tabs} tab={tab} setTab={(t) => { setTab(t); setMsg(''); }} unread={notifs.filter((n) => !n.read).length} flash={msg}>
    {tab === 'demandes' && <Requests reqs={reqs} flash={flash} refresh={refresh} />}{tab === 'etab' && <Etab key={p.id} p={p} flash={flash} refresh={refresh} />}
    {tab === 'notifs' && <Notifs list={notifs} onRead={() => { notifs.forEach((n) => db.upd('notifs', n.id, { read: true })); refresh(); }} />}</DashLayout>;
}
