import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar.jsx';
import { Field } from '../components/ui.jsx';
import Logo from '../components/Logo.jsx';
import { CITIES } from '../data/cities.js';
import { SPECIALTIES } from '../data/catalog.js';
import { useAuth } from '../context/AuthContext.jsx';
export function Login() {
  const { login } = useAuth(); const nav = useNavigate();
  const [f, setF] = useState({ email: '', pw: '' }); const [err, setErr] = useState('');
  const go = (e) => { e.preventDefault(); const r = login(f.email, f.pw); r.error ? setErr(r.error) : nav('/espace'); };
  return <><Navbar /><form className="card auth" onSubmit={go}><div className="auth-logo"><Logo size={44} /></div><h2>Se connecter</h2>
    <Field label="Adresse e-mail"><input type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></Field>
    <Field label="Mot de passe"><input type="password" value={f.pw} onChange={(e) => setF({ ...f, pw: e.target.value })} /></Field>
    {err && <p className="err">{err}</p>}<button className="btn big">Se connecter</button><p>Pas de compte ? <Link to="/inscription">Créer un compte</Link></p></form></>;
}
const CHOICES = [['patient', 'Patient'], ['cabinet', 'Cabinet médical'], ['other', 'Autre établissement de santé']];
const CATS = [['lab', 'Laboratoire d’analyses médicales'], ['radio', 'Centre de radiologie']];
export function Register() {
  const { register } = useAuth(); const nav = useNavigate();
  const [other, setOther] = useState(false); const [role, setRole] = useState(null);
  const [f, setF] = useState({ sexe: 'Femme' }); const [err, setErr] = useState('');
  const b = (k) => ({ value: f[k] || '', onChange: (e) => setF({ ...f, [k]: e.target.value }) });
  const pro = role && role !== 'patient';
  const submit = (e) => {
    e.preventDefault();
    const req = pro ? ['nom', 'prenom', 'etab', 'tel', 'email', 'adresse', 'ville', 'password'] : ['nom', 'prenom', 'naissance', 'email', 'tel', 'password'];
    if (req.some((k) => !f[k]?.trim())) return setErr('Veuillez remplir tous les champs obligatoires.');
    if (role === 'cabinet' && !(f.specialites || []).length) return setErr('Sélectionnez au moins une spécialité proposée par le cabinet.');
    if (!/^\S+@\S+\.\S+$/.test(f.email)) return setErr('Adresse e-mail invalide.');
    if (f.password.length < 6) return setErr('Le mot de passe doit contenir au moins 6 caractères.');
    const r = register({ ...f, role }); r.error ? setErr(r.error) : nav('/espace');
  };
  return <><Navbar /><div className="card auth wide"><div className="auth-logo"><Logo size={44} /></div><h2>Créer un compte</h2>
    <div className="choices">{CHOICES.map(([k, l]) => <button key={k} className={'choice' + ((k === 'other' ? other : role === k && !other) ? ' on' : '')} onClick={() => { setOther(k === 'other'); setRole(k === 'other' ? null : k); }}>{l}</button>)}</div>
    {other && <div className="choices">{CATS.map(([k, l]) => <button key={k} className={'choice' + (role === k ? ' on' : '')} onClick={() => setRole(k)}>{l}</button>)}</div>}
    {role && <form onSubmit={submit} className="fg">
      {role === 'cabinet' && <Field label="Nom du cabinet médical *"><input {...b('etab')} /></Field>}
      <Field label={pro ? 'Nom du responsable *' : 'Nom *'}><input {...b('nom')} /></Field><Field label="Prénom *"><input {...b('prenom')} /></Field>
      {!pro && <><Field label="Date de naissance *"><input type="date" {...b('naissance')} /></Field><Field label="Sexe"><select {...b('sexe')}><option>Femme</option><option>Homme</option></select></Field></>}
      {pro && <>{role !== 'cabinet' && <Field label="Nom du laboratoire ou du centre *"><input {...b('etab')} /></Field>}
        {role === 'cabinet' && <><Field label="Médecins du cabinet (un par ligne)"><textarea placeholder={'Dr Nom Prénom\nDr Nom Prénom'} {...b('medecins')} /></Field>
          <div className="f full"><span>Spécialités médicales proposées *</span><div className="chips">{SPECIALTIES.map((x) => { const on = (f.specialites || []).includes(x); return <button type="button" key={x} aria-pressed={on} className={'chip' + (on ? ' on' : '')} onClick={() => setF({ ...f, specialites: on ? f.specialites.filter((y) => y !== x) : [...(f.specialites || []), x] })}>{x}</button>; })}</div></div></>}
        <Field label="Diplômes / qualifications (pour vérification)"><input {...b('diplomes')} /></Field><Field label="Adresse complète *"><input {...b('adresse')} /></Field>
        <Field label="Ville *"><select {...b('ville')}><option value="">Choisir une ville…</option>{CITIES.map((c) => <option key={c}>{c}</option>)}</select></Field><Field label={role === 'cabinet' ? 'Horaires de consultation' : 'Horaires de travail'}><input placeholder="Ex : Lun-Ven 9h-17h" {...b('horaires')} /></Field>
        <Field label="Description des services"><textarea {...b('description')} /></Field><Field label="Informations professionnelles complémentaires"><textarea {...b('infos')} /></Field></>}
      <Field label="Adresse e-mail *"><input type="email" {...b('email')} /></Field><Field label="Téléphone *"><input {...b('tel')} /></Field>
      <Field label="Mot de passe *"><input type="password" {...b('password')} /></Field>
      {pro && <p className="hint full">Votre compte sera marqué « En attente de vérification » jusqu’à validation de vos qualifications.</p>}
      {err && <p className="err full">{err}</p>}<button className="btn big full">Créer mon compte</button></form>}
    <p>Déjà inscrit ? <Link to="/connexion">Se connecter</Link></p></div></>;
}
