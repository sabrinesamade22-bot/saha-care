import { useState, useRef } from 'react';
import { User, Search, ClipboardList, Bell, Download, FlaskConical, ScanLine, Stethoscope } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import DashLayout, { Notifs } from '../layouts/DashLayout.jsx';
import { Field, Badge, Empty, Stat, KIND_LABEL } from '../components/ui.jsx';
import { db, uid } from '../services/store.js';
import { dossierPDF } from '../services/pdf.js';
import { CITIES } from '../data/cities.js';
import { SPECS, SPECIALTIES, ANALYSE_GROUPS, EXAMS } from '../data/catalog.js';
import { searchProviders, termOptions, provSpecs, norm } from '../services/search.js';
import { ResultCard, Details } from '../components/ProviderViews.jsx';

function History({ title, items = [], onChange }) {
  const [s, setS] = useState(''); const [t, setT] = useState('');
  const add = () => { if (!s) return; onChange([...items, { spec: s, detail: t }]); setS(''); setT(''); };
  return <div className="card"><h4>{title}</h4>
    <select value={s} onChange={(e) => setS(e.target.value)}><option value="">Choisir une spécialité…</option>{Object.keys(SPECS).map((k) => <option key={k}>{k}</option>)}<option>Autre</option></select>
    {SPECS[s] && <div className="chips">{SPECS[s].map((x) => <button type="button" className="chip" key={x} onClick={() => setT(x)}>{x}</button>)}</div>}
    {s && <><input placeholder={s === 'Autre' ? 'Précisez votre information' : 'Maladie ou détails (texte libre)'} value={t} onChange={(e) => setT(e.target.value)} /><button type="button" className="btn sm" onClick={add}>Ajouter</button></>}
    <ul>{items.map((i, n) => <li key={n}><b>{i.spec}</b> : {i.detail || '—'} <button type="button" className="x" aria-label="Supprimer" onClick={() => onChange(items.filter((_, j) => j !== n))}>×</button></li>)}</ul></div>;
}
function Profil({ u, flash, refresh }) {
  const [p, setP] = useState({ antMed: [], antChir: [], ...u.profile }); const [id, setId] = useState({ nom: u.nom, prenom: u.prenom, tel: u.tel });
  const [edit, setEdit] = useState(!u.profile.saved); const [err, setErr] = useState('');
  const b = (k) => ({ value: p[k] || '', onChange: (e) => setP({ ...p, [k]: e.target.value }) });
  const toggleNone = (e) => {
    const on = e.target.checked;
    if (on && p.antMed.length && !window.confirm('Les antécédents médicaux déjà saisis seront supprimés. Continuer ?')) return;
    setP({ ...p, aucunAnt: on, antMed: on ? [] : p.antMed });
  };
  const save = (e) => {
    e.preventDefault();
    if ((p.poids && !(+p.poids > 0)) || (p.taille && !(+p.taille > 0))) return setErr('Le poids et la taille doivent être des nombres positifs.');
    const profile = { ...p, antMed: p.aucunAnt ? [] : p.antMed, saved: true, date: new Date().toISOString() };
    db.upd('users', u.id, { ...id, profile }); refresh(); setErr(''); setEdit(false); dossierPDF({ ...u, ...id }, profile); flash('Dossier médical enregistré. Le PDF a été généré.');
  };
  if (!edit) return <section><h2>Mon dossier médical</h2><div className="card"><p>Dernière mise à jour : {new Date(u.profile.date).toLocaleString('fr-FR')}</p>
    <p>Poids : {p.poids || '—'} kg · Taille : {p.taille || '—'} cm · Groupe : {p.groupe || '—'}</p><p>Allergies : {p.allergies || '—'}</p><p>Traitements : {p.traitements || '—'}</p>
    <p>Antécédents médicaux : {p.aucunAnt ? 'Rien à signaler (aucun antécédent médical)' : p.antMed.map((i) => `${i.spec} (${i.detail})`).join(', ') || '—'}</p><p>Antécédents chirurgicaux : {p.antChir.map((i) => `${i.spec} (${i.detail})`).join(', ') || '—'}</p>
    <button className="btn" onClick={() => dossierPDF(u, u.profile)}><Download size={16} /> Télécharger mon dossier PDF</button> <button className="btn ghost" onClick={() => setEdit(true)}>Mettre à jour mon dossier</button></div></section>;
  return <section><h2>Mon profil médical</h2><form onSubmit={save}><div className="card fg"><Field label="Nom"><input value={id.nom} onChange={(e) => setId({ ...id, nom: e.target.value })} required /></Field><Field label="Prénom"><input value={id.prenom} onChange={(e) => setId({ ...id, prenom: e.target.value })} required /></Field><Field label="Téléphone"><input value={id.tel || ''} onChange={(e) => setId({ ...id, tel: e.target.value })} /></Field>
    <Field label="Poids (kg)"><input type="number" {...b('poids')} /></Field><Field label="Taille (cm)"><input type="number" {...b('taille')} /></Field>
    <Field label="Groupe sanguin"><select {...b('groupe')}><option value="">Non renseigné</option>{['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map((g) => <option key={g}>{g}</option>)}</select></Field>
    <Field label="Allergies connues"><textarea {...b('allergies')} /></Field><Field label="Traitements en cours"><textarea {...b('traitements')} /></Field></div>
    <div className="card"><label className="chk none"><input type="checkbox" checked={!!p.aucunAnt} onChange={toggleNone} /><span><b>Rien à signaler</b><small>Je n’ai aucun antécédent médical, aucune maladie connue ni information particulière à déclarer.</small></span></label></div>
    {p.aucunAnt ? <div className="card muted"><h4>Antécédents médicaux</h4><p>Vous avez indiqué « Rien à signaler ». Décochez l’option ci-dessus pour ajouter des antécédents.</p></div> : <History title="Antécédents médicaux" items={p.antMed} onChange={(v) => setP({ ...p, antMed: v })} />}<History title="Antécédents chirurgicaux" items={p.antChir} onChange={(v) => setP({ ...p, antChir: v })} />
    {err && <p className="err">{err}</p>}<button className="btn big">Enregistrer mon dossier médical</button></form></section>;
}
const BOOK = {
  rdv: { title: 'Prendre un rendez-vous', term: 'Spécialité', name: 'Nom du médecin ou du cabinet', action: 'Prendre rendez-vous' },
  analyse: { title: 'Analyses biologiques', term: 'Type d’analyse', name: 'Nom du laboratoire', action: 'Demander une analyse' },
  radio: { title: 'Examens radiologiques', term: 'Type d’examen', name: 'Nom du centre', action: 'Réserver un examen' },
};
const ANALYSES = Object.values(ANALYSE_GROUPS).flat();
function Book({ kind, u, refresh, flash, go }) {
  const T = BOOK[kind]; const all = db.all('providers');
  const [city, setCity] = useState(''); const [q, setQ] = useState(''); const [name, setName] = useState(''); const [home, setHome] = useState(false);
  const [sel, setSel] = useState(null); const [detail, setDetail] = useState(null);
  const [f, setF] = useState({ mode: 'Au laboratoire' }); const [err, setErr] = useState(''); const formRef = useRef(null);
  const opts = termOptions(all, kind, kind === 'rdv' ? SPECIALTIES : kind === 'analyse' ? ANALYSES : EXAMS);
  const list = searchProviders(all, { kind, city, term: q, name, home });
  const b = (k) => ({ value: f[k] || '', onChange: (e) => setF({ ...f, [k]: e.target.value }) });
  const choose = (p) => { setSel(p); setErr(''); setF((x) => ({ ...x, service: '', mode: 'Au laboratoire' })); setTimeout(() => formRef.current?.scrollIntoView?.({ behavior: 'smooth', block: 'start' }), 50); };
  const reset = () => { setCity(''); setQ(''); setName(''); setHome(false); };
  // Service demandé : choix explicite, sinon le filtre s'il désigne un service précis de cet établissement.
  const defaultService = (p) => (kind === 'rdv' ? (provSpecs(p).some((s) => norm(s) === norm(q)) ? q : provSpecs(p)[0] || '') : (p.services.some((s) => norm(s.name) === norm(q)) ? q : ''));
  const service = sel ? f.service || defaultService(sel) : '';
  const send = (e) => {
    e.preventDefault();
    if (!f.date || !f.time || !service) return setErr('Choisissez un service, une date et une heure.');
    if (kind === 'rdv' && !f.motif) return setErr('Indiquez le motif de consultation.');
    if (kind === 'analyse' && f.mode === 'À domicile' && !f.adresse) return setErr('Indiquez votre adresse pour le prélèvement à domicile.');
    if (f.share && !u.profile.saved) return setErr('Complétez d’abord votre dossier médical pour pouvoir le partager.');
    const home = kind === 'analyse' && f.mode === 'À domicile';
    const r = { id: uid(), patientId: u.id, patientName: `${u.prenom} ${u.nom}`, patientTel: u.tel, providerId: sel.id, kind, service, date: f.date, time: f.time, mode: kind === 'analyse' ? f.mode : undefined, adresse: home ? f.adresse : undefined, motif: f.motif, notes: f.notes, share: !!f.share, dossier: f.share ? { u: { nom: u.nom, prenom: u.prenom, naissance: u.naissance, sexe: u.sexe, tel: u.tel, email: u.email }, p: u.profile } : null, status: 'En attente', createdAt: new Date().toISOString() };
    db.add('requests', r); const pu = db.all('users').find((x) => x.providerId === sel.id); if (pu) db.notify(pu.id, `Nouvelle demande de ${r.patientName} (${KIND_LABEL[kind]}).`);
    refresh(); flash('Demande envoyée. Elle n’est pas confirmée tant que le professionnel ne l’a pas acceptée.'); go('demandes');
  };
  const price = sel?.services.find((s) => s.name === service)?.price;
  return <section><h2>{T.title}</h2>
    <div className="card fg filters"><Field label="Ville"><select value={city} onChange={(e) => setCity(e.target.value)}><option value="">Toutes les villes</option>{CITIES.map((c) => <option key={c}>{c}</option>)}</select></Field>
      <Field label={T.term}><select value={q} onChange={(e) => setQ(e.target.value)}><option value="">{kind === 'rdv' ? 'Toutes les spécialités' : 'Tous les types'}</option>
        {kind === 'analyse' && <optgroup label="Catégories">{Object.keys(ANALYSE_GROUPS).map((g) => <option key={g}>{g}</option>)}</optgroup>}
        {kind === 'analyse' ? <optgroup label="Analyses">{opts.filter((o) => !ANALYSE_GROUPS[o]).map((o) => <option key={o}>{o}</option>)}</optgroup> : opts.map((o) => <option key={o}>{o}</option>)}</select></Field>
      <Field label={T.name}><input type="search" placeholder="Facultatif" value={name} onChange={(e) => setName(e.target.value)} /></Field>
      {kind === 'analyse' && <label className="chk"><input type="checkbox" checked={home} onChange={(e) => setHome(e.target.checked)} /> Prélèvement à domicile uniquement</label>}</div>
    <p className="count" aria-live="polite">{list.length} résultat{list.length > 1 ? 's' : ''}{city ? ' à ' + city : ' dans toutes les villes'}{q ? ' · ' + q : ''}</p>
    {list.length === 0 ? <div className="empty"><Search /><p>Aucun résultat pour {[city && `la ville ${city}`, q && `« ${q} »`, name && `le nom « ${name} »`].filter(Boolean).join(', ') || 'ces critères'}.</p><button type="button" className="btn sm ghost" onClick={reset}>Réinitialiser les filtres</button></div>
      : <div className="grid">{list.map((p) => <ResultCard key={p.id} p={p} term={kind === 'rdv' ? '' : q} chosen={sel?.id === p.id} actionLabel={T.action} onDetails={setDetail} onChoose={choose} />)}</div>}
    {detail && <Details p={detail} term={kind === 'rdv' ? '' : q} actionLabel={T.action} onClose={() => setDetail(null)} onChoose={choose} />}
    {sel && <form ref={formRef} className="card" onSubmit={send}><h3>Demande auprès de {sel.name}</h3><div className="fg">
      {kind === 'rdv' && provSpecs(sel).length > 1 && <Field label="Spécialité"><select value={service} onChange={(e) => setF({ ...f, service: e.target.value })}>{provSpecs(sel).map((s) => <option key={s}>{s}</option>)}</select></Field>}
      {kind !== 'rdv' && <Field label={kind === 'analyse' ? 'Analyse' : 'Examen'}><select value={service} onChange={(e) => setF({ ...f, service: e.target.value })}><option value="">Choisir…</option>{sel.services.map((s) => <option key={s.name}>{s.name}</option>)}</select></Field>}
      {kind === 'analyse' && <Field label="Mode de réalisation"><select {...b('mode')}><option>Au laboratoire</option>{sel.home && <option>À domicile</option>}</select></Field>}
      {f.mode === 'À domicile' && kind === 'analyse' && <Field label="Votre adresse"><input {...b('adresse')} /></Field>}
      <Field label="Date souhaitée"><input type="date" min={new Date().toISOString().slice(0, 10)} {...b('date')} /></Field>
      <Field label="Heure souhaitée"><select {...b('time')}><option value="">Choisir…</option>{sel.slots.map((s) => <option key={s}>{s}</option>)}</select></Field>
      {kind === 'rdv' && <Field label="Motif de consultation"><input {...b('motif')} /></Field>}
      <Field label="Symptômes / informations complémentaires"><textarea {...b('notes')} /></Field></div>
      {price > 0 && <p>Prix indicatif : <b>{price} MAD</b></p>}
      {kind === 'rdv' && <label className="chk"><input type="checkbox" checked={!!f.share} onChange={(e) => setF({ ...f, share: e.target.checked })} /> J’accepte de partager mon dossier médical PDF avec ce professionnel.</label>}
      {err && <p className="err">{err}</p>}<button className="btn big">Envoyer la demande</button></form>}</section>;
}
function Requests({ reqs, setTab, flash, refresh }) {
  const provs = db.all('providers');
  const cancel = (r) => { db.upd('requests', r.id, { status: 'Annulée' }); const pu = db.all('users').find((x) => x.providerId === r.providerId); if (pu) db.notify(pu.id, `${r.patientName} a annulé sa demande.`); refresh(); flash('Demande annulée.'); };
  return <section><h2>Mes demandes et historique</h2><div className="stats">{['En attente', 'Acceptée', 'Refusée', 'Annulée'].map((s) => <Stat key={s} n={reqs.filter((r) => r.status === s).length} label={s} />)}</div>
    {reqs.length === 0 ? <Empty icon={<ClipboardList />} text="Vous n’avez encore envoyé aucune demande." /> : <div className="tw"><table><thead><tr><th>Type</th><th>Professionnel</th><th>Service</th><th>Date</th><th>Statut</th><th></th></tr></thead><tbody>
      {[...reqs].reverse().map((r) => <tr key={r.id}><td>{KIND_LABEL[r.kind]}</td><td>{provs.find((p) => p.id === r.providerId)?.name}</td><td>{r.service}</td><td>{r.date} {r.time}</td>
        <td><Badge s={r.status} />{r.reason && <small>{r.reason}</small>}{r.proposal && <small>Créneau proposé : {r.proposal}</small>}</td>
        <td>{r.status === 'En attente' && <button className="btn sm ghost" onClick={() => cancel(r)}>Annuler</button>}{r.status === 'Refusée' && r.kind === 'rdv' && <button className="btn sm" onClick={() => setTab('rdv')}>Choisir un autre médecin</button>}</td></tr>)}</tbody></table></div>}</section>;
}
export default function PatientSpace() {
  const { user: u, refresh } = useAuth(); const [tab, setTab] = useState('profil'); const [msg, setMsg] = useState('');
  const flash = (m) => { setMsg(m); setTimeout(() => setMsg(''), 6000); };
  const reqs = db.all('requests').filter((r) => r.patientId === u.id); const notifs = db.all('notifs').filter((n) => n.userId === u.id);
  const tabs = [['profil', 'Profil médical', <User size={18} />], ['rdv', 'Médecins', <Stethoscope size={18} />], ['analyse', 'Analyses biologiques', <FlaskConical size={18} />], ['radio', 'Examens radiologiques', <ScanLine size={18} />], ['demandes', 'Mes demandes', <ClipboardList size={18} />], ['notifs', 'Notifications', <Bell size={18} />]].map(([k, label, icon]) => ({ k, label, icon }));
  const props = { u, refresh, flash, go: setTab };
  return <DashLayout tabs={tabs} tab={tab} setTab={(t) => { setTab(t); setMsg(''); }} unread={notifs.filter((n) => !n.read).length} flash={msg}>
    {tab === 'profil' && <Profil key={u.profile.date} {...props} />}{['rdv', 'analyse', 'radio'].includes(tab) && <Book key={tab} kind={tab} {...props} />}
    {tab === 'demandes' && <Requests reqs={reqs} setTab={setTab} flash={flash} refresh={refresh} />}
    {tab === 'notifs' && <Notifs list={notifs} onRead={() => { notifs.forEach((n) => db.upd('notifs', n.id, { read: true })); refresh(); }} />}</DashLayout>;
}
