import { Link } from 'react-router-dom';
import { Stethoscope, FlaskConical, ScanLine, FileText, ShieldCheck, Bell } from 'lucide-react';
import Navbar from '../components/Navbar.jsx';
import { DemoNotice } from '../components/ui.jsx';
import Logo from '../components/Logo.jsx';
const F = [[<Stethoscope />, 'Consultations', 'Trouvez un médecin ou un cabinet par ville et spécialité, puis envoyez une demande de rendez-vous.'], [<FlaskConical />, 'Analyses biologiques', 'Choisissez votre ville et votre analyse, comparez les laboratoires et leurs prix indicatifs.'], [<ScanLine />, 'Examens radiologiques', 'Radiographie, échographie, scanner, IRM : trouvez un centre dans votre ville et réservez.'], [<FileText />, 'Dossier médical PDF', 'Un dossier à jour, que vous partagez uniquement si vous le décidez.'], [<ShieldCheck />, 'Professionnels vérifiés', 'Les comptes professionnels sont « En attente de vérification » jusqu’à validation.'], [<Bell />, 'Suivi des demandes', 'Aucun rendez-vous n’est confirmé avant l’acceptation du professionnel.']];
export default function Home() {
  return <><Navbar /><DemoNotice />
    <header className="hero"><h1>Votre santé, plus près de vous.</h1><p>Saha-Care met en relation patients, médecins, laboratoires et centres de radiologie au Maroc.</p>
      <div><Link className="btn big" to="/inscription">Créer un compte</Link> <Link className="btn big ghost" to="/connexion">Se connecter</Link></div></header>
    <section className="grid feat">{F.map(([i, t, d]) => <div className="card" key={t}><div className="ico">{i}</div><h3>{t}</h3><p>{d}</p></div>)}</section>
    <section className="demo card"><h3>Comptes de démonstration</h3><p>Mot de passe : <code>demo1234</code> — patient@demo.ma, cabinet@demo.ma, medecin@demo.ma, labo@demo.ma, radio@demo.ma</p></section>
    <footer><Logo size={26} /><p>Saha-Care — projet de démonstration. Les données restent dans votre navigateur (LocalStorage).</p></footer></>;
}
