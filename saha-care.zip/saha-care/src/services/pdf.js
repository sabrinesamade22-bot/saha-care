import { jsPDF } from 'jspdf';
// Génère le PDF à partir des données réelles du patient (identité u + profil médical p).
export function dossierPDF(u, p) {
  const d = new jsPDF(); let y = 44;
  d.setFillColor(200, 40, 60); d.rect(0, 0, 210, 30, 'F');
  d.setTextColor(255); d.setFontSize(20); d.text('Saha-Care', 14, 19); d.setFontSize(12); d.text('Dossier médical', 196, 19, { align: 'right' });
  const H = (t) => { if (y > 260) { d.addPage(); y = 20; } d.setFontSize(13); d.setTextColor(200, 40, 60); d.text(t, 14, y); d.setDrawColor(190, 185, 180); d.line(14, y + 2, 196, y + 2); y += 11; d.setTextColor(55); d.setFontSize(11); };
  const L = (a, b) => { const t = d.splitTextToSize(`${a} : ${b || 'Non renseigné'}`, 180); d.text(t, 14, y); y += 6 * t.length; if (y > 280) { d.addPage(); y = 20; } };
  H('Identité'); L('Nom', u.nom); L('Prénom', u.prenom); L('Date de naissance', u.naissance); L('Sexe', u.sexe); L('Téléphone', u.tel); L('E-mail', u.email); y += 4;
  H('Données physiques'); L('Poids', p.poids && p.poids + ' kg'); L('Taille', p.taille && p.taille + ' cm'); L('Groupe sanguin', p.groupe); y += 4;
  H('Informations médicales'); L('Allergies', p.allergies); L('Traitements en cours', p.traitements); y += 4;
  H('Antécédents médicaux'); (p.aucunAnt ? [{ spec: 'Rien à signaler', detail: 'aucun antécédent médical déclaré' }] : p.antMed?.length ? p.antMed : [{ spec: 'Aucun renseigné', detail: '' }]).forEach((i) => L(i.spec, i.detail)); y += 4;
  H('Antécédents chirurgicaux'); (p.antChir?.length ? p.antChir : [{ spec: 'Aucun renseigné', detail: '' }]).forEach((i) => L(i.spec, i.detail));
  d.setFontSize(9); d.setTextColor(120); d.text(`Document généré le ${new Date().toLocaleString('fr-FR')} — Saha-Care (démonstration)`, 14, 289);
  d.save(`dossier-medical-${u.nom}-${u.prenom}.pdf`);
}
