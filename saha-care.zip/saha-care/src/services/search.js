// Moteur de recherche (fonctions pures, sans dépendance à React ni au stockage → facile à tester).
import { ANALYSE_GROUPS } from '../data/catalog.js';

// Normalise : sans accents, minuscules, espaces/traits d'union unifiés ("Béni Mellal" = "beni  mellal").
export const norm = (s) => String(s ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[-’']/g, ' ').replace(/\s+/g, ' ').trim();

export const KIND_TYPES = { rdv: ['doctor', 'cabinet'], analyse: ['lab'], radio: ['radio'] };
// Compatibilité avec les anciennes fiches qui n'avaient qu'un champ `specialty`.
export const provSpecs = (p) => (p.specialties?.length ? p.specialties : p.specialty ? [p.specialty] : []);
export const hasPrice = (s) => Number(s?.price) > 0;

// Un type d'analyse peut être une catégorie (« Analyse sanguine ») ou une analyse précise (« Glycémie »).
const wantedNames = (term) => new Set((ANALYSE_GROUPS[term] || [term]).map(norm));

export function searchProviders(providers, { kind, city = '', term = '', name = '', home = false } = {}) {
  const types = KIND_TYPES[kind] || [];
  const c = norm(city); const t = norm(term); const q = norm(name);
  const wanted = kind === 'rdv' ? null : wantedNames(term);
  return providers
    .filter((p) => types.includes(p.type))
    .filter((p) => !c || norm(p.city) === c)
    .filter((p) => !t || (kind === 'rdv' ? provSpecs(p).some((s) => norm(s) === t) : (p.services || []).some((s) => wanted.has(norm(s.name)))))
    .filter((p) => !q || [p.name, p.cabinet, ...(p.doctors || [])].some((x) => norm(x).includes(q)))
    .filter((p) => !home || p.home)
    .sort((a, b) => a.name.localeCompare(b.name, 'fr'));
}

// Types proposés dans le filtre : catalogue de référence + ce qui existe réellement dans les données.
export function termOptions(providers, kind, catalog) {
  const fromData = providers.filter((p) => KIND_TYPES[kind].includes(p.type)).flatMap((p) => (kind === 'rdv' ? provSpecs(p) : (p.services || []).map((s) => s.name)));
  const seen = new Set(); const out = [];
  [...catalog, ...fromData].forEach((x) => { if (x && !seen.has(norm(x))) { seen.add(norm(x)); out.push(x); } });
  return out;
}
