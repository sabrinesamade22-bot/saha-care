import { DEMO } from '../data/demo.js';
const K = 'sahacare_';
const get = (k, d) => { try { return JSON.parse(localStorage.getItem(K + k)) ?? d; } catch { return d; } };
const set = (k, v) => localStorage.setItem(K + k, JSON.stringify(v));
export const uid = () => Math.random().toString(36).slice(2, 10);
// À incrémenter à chaque changement du jeu de données de démonstration : au prochain chargement, les
// fiches de démonstration sont régénérées. Les comptes et fiches créés par les utilisateurs sont conservés.
export const DATA_VERSION = 2;
export const db = {
  init() {
    if (!get('seeded')) { set('users', DEMO.users); set('requests', DEMO.requests); set('notifs', []); set('seeded', 1); }
    if (get('dataVersion', 0) < DATA_VERSION) {
      const demoIds = new Set(DEMO.providers.map((p) => p.id));
      const own = get('providers', []).filter((p) => !p.demo && !demoIds.has(p.id));
      set('providers', [...DEMO.providers, ...own]);
      const users = get('users', []); const have = new Set(users.map((u) => u.id));
      set('users', [...users, ...DEMO.users.filter((u) => !have.has(u.id))]);
      set('dataVersion', DATA_VERSION);
    }
  },
  all: (k) => get(k, []),
  add(k, item) { set(k, [...get(k, []), item]); return item; },
  upd(k, id, patch) { set(k, get(k, []).map((x) => (x.id === id ? { ...x, ...patch } : x))); },
  notify(userId, text) { db.add('notifs', { id: uid(), userId, text, date: new Date().toISOString(), read: false }); },
  session: () => get('session', null),
  setSession: (id) => set('session', id),
};
